/*
PROBLEM STATEMENT:
Write a C++ program that prints a welcome message with multiple lines and formatting.

Requirements:
1. Print a welcome message for a programming course
2. Include course details like:
   - Course name
   - Duration
   - Instructor
   - University/Institute name

3. Use different formatting techniques:
   - Empty lines for spacing
   - Decorative characters
   - Multiple cout statements

Expected Output:
Welcome to Programming Fundamentals!

Course Details:
===============
Course: Programming Fundamentals (PF)
Duration: 16 Weeks
Instructor: Prof. Ahmad
Institute: XYZ University

Good luck with your programming journey!
===============
*/

#include <iostream>
using namespace std;

int main() {
    // Write your cout statements here to create the welcome message
    
    
    
    return 0;
}
