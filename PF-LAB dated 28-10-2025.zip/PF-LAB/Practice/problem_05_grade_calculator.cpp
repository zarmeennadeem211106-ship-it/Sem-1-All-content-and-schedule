/*
PROBLEM STATEMENT:
Create a C++ program that prints a detailed program structure explanation.

Requirements:
1. Print a title explaining what the program does
2. List and explain each part of a basic C++ program:
   - Preprocessor directives
   - Namespace declaration
   - Main function
   - Program statements
   - Return statement

3. Include examples of each component
4. Use clear formatting and spacing

Expected Output:
========================================
    UNDERSTANDING C++ PROGRAM STRUCTURE
========================================

1. Preprocessor Directive:
   Example: #include <iostream>
   Purpose: Includes input/output stream library

2. Namespace Declaration:
   Example: using namespace std;
   Purpose: Allows use of standard library without std::

3. Main Function:
   Example: int main()
   Purpose: Entry point of the program

4. Program Body:
   Example: cout << "Hello World!";
   Purpose: Contains the actual program logic

5. Return Statement:
   Example: return 0;
   Purpose: Indicates successful program completion

========================================
*/

#include <iostream>
using namespace std;

int main() {
    // Write your cout statements here to explain program structure
    
    
    
    return 0;
}
