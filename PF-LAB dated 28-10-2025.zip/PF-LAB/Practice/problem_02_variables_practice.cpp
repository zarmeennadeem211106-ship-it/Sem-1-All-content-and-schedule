/*
PROBLEM STATEMENT:
Write a C++ program that demonstrates the basic structure by printing information about program components.

Requirements:
1. Print a title for your program
2. Print the basic components of a C++ program structure:
   - Header files
   - Namespace
   - Main function
   - Program body
   - Return statement

3. Use proper formatting with decorative elements
4. Each component should be on a separate line

Expected Output:
=== C++ PROGRAM STRUCTURE ===
Component 1: #include <iostream>
Component 2: using namespace std;
Component 3: int main()
Component 4: Program statements
Component 5: return 0;
=============================
*/

#include <iostream>
using namespace std;

int main() {
    // Write your cout statements here to print the program structure
    
    
    
    return 0;
}
