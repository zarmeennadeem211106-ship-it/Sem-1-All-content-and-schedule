/*
PROBLEM STATEMENT:
Write a C++ program that prints the following message on the screen:

Hello World!
Welcome to C++ Programming!
This is my first program.

Instructions:
1. Use the basic C++ program structure
2. Include the necessary header file
3. Use the correct namespace
4. Write the main function properly
5. Use cout to print each line
6. Use endl to move to the next line
7. End with return 0;

Expected Output:
Hello World!
Welcome to C++ Programming!
This is my first program.
*/

#include <iostream>
using namespace std;

int main() {
    // Write your cout statements here
    
    
    
    return 0;
}
