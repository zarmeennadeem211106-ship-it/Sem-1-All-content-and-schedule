/*
PROBLEM STATEMENT:
Create a C++ program that prints a formatted student information card.

Requirements:
1. Print a decorative border using asterisks (*)
2. Print student information in a formatted way:
   - Student Name
   - Roll Number
   - Class
   - Subject
   - Teacher Name

3. Close with the same decorative border
4. Use proper spacing and alignment

Expected Output:
********************************
*      STUDENT ID CARD         *
********************************
Student Name: Ali Ahmed
Roll Number: 2024-PF-001
Class: BSCS 1st Semester
Subject: Programming Fundamentals
Teacher: Dr. Smith
********************************
*/

#include <iostream>
using namespace std;

int main() {
    // Write your cout statements here to create the student ID card
    
    
    
    return 0;
}
