#include <iostream>
using namespace std;

int main() {
    cout << "=== C++ Program Structure Demo ===" << endl;
    cout << "1. Header files: #include <iostream>" << endl;
    cout << "2. Namespace: using namespace std;" << endl;
    cout << "3. Main function: int main()" << endl;
    cout << "4. Program body with statements" << endl;
    cout << "5. Return statement: return 0;" << endl;
    cout << "=================================" << endl;
    
    return 0;
}
