#include <iostream>
using namespace std;

int main() {
    cout << "****************************" << endl;
    cout << "*    STUDENT INFORMATION   *" << endl;
    cout << "****************************" << endl;
    cout << "Name: John Smith" << endl;
    cout << "Roll No: 2024-CS-001" << endl;
    cout << "Course: Programming Fundamentals" << endl;
    cout << "Semester: 1st" << endl;
    cout << "University: ABC University" << endl;
    cout << "****************************" << endl;
    
    return 0;
}
