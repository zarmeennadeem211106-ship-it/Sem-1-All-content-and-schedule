#include <iostream>
using namespace std;

int main() {
    cout << "Welcome to Programming Fundamentals!" << endl;
    cout << "Today we will learn C++ basics." << endl;
    cout << "" << endl;
    cout << "Key Points:" << endl;
    cout << "- Every C++ program starts with main() function" << endl;
    cout << "- Use cout to print messages" << endl;
    cout << "- End statements with semicolon ;" << endl;
    cout << "- Use endl for new line" << endl;
    
    return 0;
}
