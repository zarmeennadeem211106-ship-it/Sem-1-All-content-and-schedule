#include <iostream>
using namespace std;

int main() {
    cout << "Hello World!" << endl;
    cout << "This is my first C++ program." << endl;
    cout << "Programming is fun!" << endl;
    
    return 0;
}
