#include <iostream>
using namespace std;

int main() {
    cout << "======================================" << endl;
    cout << "        BASIC C++ PROGRAM" << endl;
    cout << "======================================" << endl;
    cout << endl;
    cout << "Parts of a C++ Program:" << endl;
    cout << "1. Preprocessor Directive: #include <iostream>" << endl;
    cout << "2. Namespace Declaration: using namespace std;" << endl;
    cout << "3. Main Function: int main()" << endl;
    cout << "4. Opening Brace: {" << endl;
    cout << "5. Program Statements" << endl;
    cout << "6. Return Statement: return 0;" << endl;
    cout << "7. Closing Brace: }" << endl;
    cout << endl;
    cout << "This program demonstrates message printing!" << endl;
    cout << "======================================" << endl;
    
    return 0;
}
